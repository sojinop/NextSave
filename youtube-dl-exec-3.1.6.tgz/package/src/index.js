'use strict'

const dargs = require('dargs')
const $ = require('tinyspawn')

const constants = require('./constants')

const args = (flags = {}) => dargs(flags, { useEquals: false }).filter(Boolean)

const isJSON = (str = '') => str.startsWith('{')

const parse = ({ stdout, stderr, ...details }) => {
  if (details.exitCode === 0) {
    return isJSON(stdout) ? JSON.parse(stdout) : stdout
  }
  throw Object.assign(new Error(stderr), { stderr, stdout }, details)
}

const create = binaryPath => {
  const needsQuoting = process.platform === 'win32' && /\s/.test(binaryPath)
  const safeBinaryPath = needsQuoting ? `"${binaryPath}"` : binaryPath
  const fn = (...args) =>
    fn
      .exec(...args)
      .then(parse)
      .catch(parse)
  fn.exec = (url, flags, opts = {}) => {
    const fullArgs = [url].concat(args(flags))
    if (needsQuoting) opts.shell = true
    return $(safeBinaryPath, fullArgs, opts)
  }
  return fn
}

const update = (binaryPath = constants.YOUTUBE_DL_PATH) => $(binaryPath, ['-U'])

const defaultInstance = create(constants.YOUTUBE_DL_PATH)

module.exports = defaultInstance
module.exports.youtubeDl = defaultInstance
module.exports.create = create
module.exports.update = update
module.exports.args = args
module.exports.isJSON = isJSON
module.exports.constants = constants
